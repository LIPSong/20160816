/**
 * Created by liuyujing on 16/9/23.
 */

(function () {
    var name = "星矢";

    function att() {
        console.log("打怪物");
    }
})();